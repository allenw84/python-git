#coding=UTF-8
import socket
import time
import binascii
import sys

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
server.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
# Set a timeout so the socket does not block
# indefinitely when trying to receive data.
server.settimeout(0.2)
server.bind(("", 44444))
fh = open(r'1.jpg','rb')
fh2 = open(r'2.jpg','rb')
fh3 = open(r'3.jpg','rb')
fh4 = open(r'4.jpg','rb')
fh5 = open(r'5.jpg','rb')

a = fh.read()
b = fh2.read()
c = fh3.read()
d = fh4.read()
e = fh5.read()

fh.close()

message = b"1234"

# hexstr = binascii.b2a_hex(a)
# print(sys.getsizeof(hexstr))
# hexstr = binascii.b2a_hex(b)
# print(sys.getsizeof(hexstr))
# hexstr = binascii.b2a_hex(c)
# print(sys.getsizeof(hexstr))
#change to binary
#img = binascii.a2b_hex(hexstr)
#save image
#image = wx.ImageFromStream(cStringIO.StringIO(img), wx.BITMAP_TYPE_JPEG)
#image.SaveFile('temp.jpg', wx.BITMAP_TYPE_JPEG)
i = 1
# hexstr = 1
while True:

	if i%5 == 1:
		hexstr = binascii.b2a_hex(a)
	elif i%5 == 2:
		hexstr = binascii.b2a_hex(b)
	elif i%5 == 3:
		hexstr = binascii.b2a_hex(c)
	elif i%5 == 4:
		hexstr = binascii.b2a_hex(d)
	else:
		hexstr = binascii.b2a_hex(e)

	server.sendto(hexstr, ('192.168.50.255', 37020))
	print("message sent!")
	time.sleep(1)

	i = i + 1

